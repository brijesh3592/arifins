  <section class="panel">
                <header class="panel-heading" style="padding: 18px 15px;">
                  Courses List
                    <a href="<?php echo site_url('dashboard/new_course');?>" style="float:right"class="btn btn-s-md btn-primary">New Course</a>
                </header>
                <div class="row text-sm wrapper">
                  <div class="col-sm-5 m-b-xs">
                    <select class="input-sm form-control input-s-sm inline">
                      <option value="0">Bulk action</option>
                      <option value="1">Delete selected</option>
                      <option value="2">Bulk edit</option>
                      <option value="3">Export</option>
                    </select>
                    <button class="btn btn-sm btn-white">Apply</button>                
                  </div>
                  <div class="col-sm-4 m-b-xs">
                    <div class="btn-group" data-toggle="buttons">
                      <label class="btn btn-sm btn-white active">
                        <input type="radio" name="options" id="option1"> Day
                      </label>
                      <label class="btn btn-sm btn-white">
                        <input type="radio" name="options" id="option2"> Week
                      </label>
                      <label class="btn btn-sm btn-white">
                        <input type="radio" name="options" id="option2"> Month
                      </label>
                    </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="input-group">
                      <input type="text" class="input-sm form-control" placeholder="Search">
                      <span class="input-group-btn">
                        <button class="btn btn-sm btn-white" type="button">Go!</button>
                      </span>
                    </div>
                  </div>
                </div>
                <div class="table-responsive">
                  <table class="table table-striped b-t text-sm">
                    <thead>
                      <tr>
                        <th width="20"><input type="checkbox"></th>
                        <th> Course Id </th>
                        <th class="th-sortable" data-toggle="class">Course </th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th width="30">Duration</th>
						<th width="30">Fees</th>
                      </tr>
                    </thead>
                    <tbody>
					<?php foreach($courses as $key =>$c){ ?>
                      <tr>
                        <td><input type="checkbox" name="post[]" value="2"></td>
                        <td><?php echo $key;?></td>
                        <td><?php echo $c['name'];?></td>
                        <td><?php echo $c['start_date'];?></td>
                        <td><?php echo $c['end_date'];?></td>
						<td><?php echo $c['duration'];?></td>
						<td><?php echo $c['fees'];?></td>
                        
                      </tr>
					<?php } ?>
                    </tbody>
                  </table>
                </div>
               