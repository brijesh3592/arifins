  <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a>
    </section>
    <!-- /.vbox -->
  </section>
	<script src="<?php echo base_url();?>/assets/js/jquery.min.js"></script>
  <!-- Bootstrap -->
  <script src="<?php echo base_url();?>/assets/js/bootstrap.js"></script>
  <!-- Sparkline Chart -->
  <script src="<?php echo base_url();?>/assets/js/charts/sparkline/jquery.sparkline.min.js"></script>
  <!-- App -->
  <script src="<?php echo base_url();?>/assets/js/app.js"></script>
  <script src="<?php echo base_url();?>/assets/js/app.plugin.js"></script>
  <script src="<?php echo base_url();?>/assets/js/app.data.js"></script>  
</body>
</html>